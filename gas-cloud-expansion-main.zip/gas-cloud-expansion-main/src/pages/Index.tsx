import { GasSimulation } from "@/components/GasSimulation";

const Index = () => {
  return <GasSimulation />;
};

export default Index;
