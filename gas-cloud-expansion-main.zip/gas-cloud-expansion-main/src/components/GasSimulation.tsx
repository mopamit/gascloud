import { useEffect, useRef, useState, useCallback } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Play, Pause, RotateCcw } from "lucide-react";

interface CloudPoint {
  x: number;
  y: number;
  intensity: number;
  radius: number;
  drift: { x: number; y: number };
}

interface GasMetrics {
  volume: number;
  density: number;
  pressure: number;
  temperature: number;
}

export const GasSimulation = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  const [isRunning, setIsRunning] = useState(false);
  const [cloudPoints, setCloudPoints] = useState<CloudPoint[]>([]);
  const [containerRadius, setContainerRadius] = useState(120);
  const [expansion, setExpansion] = useState(50);
  const [metrics, setMetrics] = useState<GasMetrics>({
    volume: 0,
    density: 0,
    pressure: 0,
    temperature: 1
  });

  const CLOUD_POINTS = 80;
  const CANVAS_WIDTH = 600;
  const CANVAS_HEIGHT = 400;
  const GAS_MASS = 100; // מסת החומר בגרם

  const initializeCloud = useCallback(() => {
    const newCloudPoints: CloudPoint[] = [];
    const centerX = CANVAS_WIDTH / 2;
    const centerY = CANVAS_HEIGHT / 2;
    const initialRadius = containerRadius * 0.4;
    
    for (let i = 0; i < CLOUD_POINTS; i++) {
      const angle = Math.random() * 2 * Math.PI;
      const distance = Math.random() * initialRadius;
      
      newCloudPoints.push({
        x: centerX + Math.cos(angle) * distance,
        y: centerY + Math.sin(angle) * distance,
        intensity: 0.3 + Math.random() * 0.7,
        radius: 8 + Math.random() * 12,
        drift: {
          x: (Math.random() - 0.5) * expansion / 100,
          y: (Math.random() - 0.5) * expansion / 100
        }
      });
    }
    setCloudPoints(newCloudPoints);
  }, [containerRadius, expansion]);

  const updateMetrics = useCallback((currentCloudPoints: CloudPoint[]) => {
    // נפח המיכל
    const volume = Math.PI * containerRadius * containerRadius;
    
    // צפיפות = מסת החומר / נפח (כאשר הנפח גדל, הצפיפות יורדת)
    const density = GAS_MASS / volume;
    
    // לחץ - מושפע מהצפיפות ומהאנרגיה התרמית
    const avgIntensity = currentCloudPoints.length > 0 ? currentCloudPoints.reduce((sum, p) => sum + p.intensity, 0) / currentCloudPoints.length : 0;
    const thermalFactor = expansion / 50; // אנרגיה תרמית
    const pressure = density * thermalFactor * avgIntensity * 10000;
    
    setMetrics({
      volume: Math.round(volume),
      density: Math.round(density * 10000) / 10000, // 4 ספרות אחרי הנקודה
      pressure: Math.round(pressure),
      temperature: thermalFactor
    });
  }, [containerRadius, expansion]);

  const animate = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    setCloudPoints(prevCloudPoints => {
      const newCloudPoints = prevCloudPoints.map(point => {
        let { x, y, drift, intensity, radius } = point;
        
        // Update position with gentle drift
        x += drift.x;
        y += drift.y;

        // Add random turbulence
        x += (Math.random() - 0.5) * 0.5;
        y += (Math.random() - 0.5) * 0.5;

        // Boundary interaction - gentle bouncing
        const centerX = CANVAS_WIDTH / 2;
        const centerY = CANVAS_HEIGHT / 2;
        const dx = x - centerX;
        const dy = y - centerY;
        const distance = Math.sqrt(dx * dx + dy * dy);

        if (distance > containerRadius - radius) {
          // Gentle reflection with some randomness
          const nx = dx / distance;
          const ny = dy / distance;
          
          drift.x = -drift.x * 0.8 + (Math.random() - 0.5) * 0.2;
          drift.y = -drift.y * 0.8 + (Math.random() - 0.5) * 0.2;
          
          // Keep inside boundary
          x = centerX + nx * (containerRadius - radius);
          y = centerY + ny * (containerRadius - radius);
        }

        // Gradually adjust intensity and radius based on container size
        const targetIntensity = Math.min(1, containerRadius / 150);
        intensity = intensity * 0.99 + targetIntensity * 0.01;
        
        return { ...point, x, y, drift, intensity, radius };
      });

      updateMetrics(newCloudPoints);
      return newCloudPoints;
    });

    animationRef.current = requestAnimationFrame(animate);
  }, [containerRadius, updateMetrics]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.fillStyle = 'hsl(220, 60%, 15%)';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    const centerX = CANVAS_WIDTH / 2;
    const centerY = CANVAS_HEIGHT / 2;

    // Create cloud effect using multiple layers
    ctx.globalCompositeOperation = 'screen';
    
    // Layer 1: Base cloud density
    const mainGradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, containerRadius * 0.9);
    const avgIntensity = cloudPoints.length > 0 ? cloudPoints.reduce((sum, p) => sum + p.intensity, 0) / cloudPoints.length : 0;
    const cloudAlpha = Math.min(0.7, avgIntensity * 0.8);
    
    mainGradient.addColorStop(0, `hsla(200, 90%, 85%, ${cloudAlpha})`);
    mainGradient.addColorStop(0.3, `hsla(205, 85%, 75%, ${cloudAlpha * 0.8})`);
    mainGradient.addColorStop(0.6, `hsla(210, 80%, 65%, ${cloudAlpha * 0.5})`);
    mainGradient.addColorStop(0.8, `hsla(215, 75%, 55%, ${cloudAlpha * 0.2})`);
    mainGradient.addColorStop(1, `hsla(220, 70%, 45%, 0)`);
    
    ctx.fillStyle = mainGradient;
    ctx.beginPath();
    ctx.arc(centerX, centerY, containerRadius * 0.9, 0, 2 * Math.PI);
    ctx.fill();

    // Layer 2: Add cloud texture using point positions
    ctx.globalCompositeOperation = 'source-over';
    cloudPoints.forEach(point => {
      const cloudSize = point.radius * 3;
      const gradient = ctx.createRadialGradient(
        point.x, point.y, 0,
        point.x, point.y, cloudSize
      );
      
      const intensity = point.intensity * 0.25;
      gradient.addColorStop(0, `hsla(195, 100%, 90%, ${intensity})`);
      gradient.addColorStop(0.5, `hsla(205, 90%, 80%, ${intensity * 0.6})`);
      gradient.addColorStop(1, `hsla(215, 80%, 70%, 0)`);
      
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(point.x, point.y, cloudSize, 0, 2 * Math.PI);
      ctx.fill();
    });

    // Layer 3: Soft outer glow
    const outerGlow = ctx.createRadialGradient(centerX, centerY, containerRadius * 0.7, centerX, centerY, containerRadius);
    outerGlow.addColorStop(0, `hsla(190, 100%, 95%, 0.15)`);
    outerGlow.addColorStop(0.5, `hsla(200, 95%, 85%, 0.10)`);
    outerGlow.addColorStop(1, `hsla(210, 90%, 75%, 0)`);
    
    ctx.fillStyle = outerGlow;
    ctx.beginPath();
    ctx.arc(centerX, centerY, containerRadius, 0, 2 * Math.PI);
    ctx.fill();

    ctx.globalCompositeOperation = 'source-over';

    // Draw container boundary
    ctx.beginPath();
    ctx.arc(centerX, centerY, containerRadius, 0, 2 * Math.PI);
    ctx.strokeStyle = 'hsl(195, 100%, 80%)';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Add subtle glow to container
    ctx.shadowBlur = 8;
    ctx.shadowColor = 'hsl(195, 100%, 80%)';
    ctx.stroke();
    ctx.shadowBlur = 0;

  }, [cloudPoints, containerRadius]);

  useEffect(() => {
    if (isRunning) {
      animate();
    } else {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    }

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isRunning, animate]);

  useEffect(() => {
    initializeCloud();
  }, [initializeCloud]);

  const toggleSimulation = () => {
    setIsRunning(!isRunning);
  };

  const resetSimulation = () => {
    setIsRunning(false);
    setContainerRadius(120);
    setExpansion(50);
    setTimeout(initializeCloud, 100);
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8" dir="rtl">
          <h1 className="text-4xl font-bold mb-4 text-white">
            סימולציית התפשטות גז
          </h1>
          <p className="text-white text-lg">
            הדמיה של התפשטות הגז בכלי בנפחים שונים
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-6">
          {/* Simulation Canvas */}
          <div className="lg:col-span-3">
            <Card className="p-6 bg-card border-card-border">
              <div className="relative">
                <canvas
                  ref={canvasRef}
                  width={CANVAS_WIDTH}
                  height={CANVAS_HEIGHT}
                  className="border border-border rounded-lg bg-canvas-bg w-full"
                  style={{ maxWidth: '100%', height: 'auto' }}
                />
                <div className="absolute bottom-4 left-4 bg-control-panel/90 backdrop-blur-sm rounded-lg p-3 border border-border">
                  <div className="flex items-center gap-3">
                    <Button
                      onClick={toggleSimulation}
                      variant="outline"
                      size="sm"
                      className="bg-background/50"
                    >
                      {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                    </Button>
                    <Button
                      onClick={resetSimulation}
                      variant="outline"
                      size="sm"
                      className="bg-background/50"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Controls and Metrics */}
          <div className="space-y-6">
            {/* Controls */}
            <Card className="p-6 bg-control-panel border-card-border" dir="rtl">
              <h3 className="text-lg font-semibold mb-4 text-primary text-right">בקרות</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block text-right">נפח מכל</label>
                  <Slider
                    value={[containerRadius]}
                    onValueChange={(value) => setContainerRadius(value[0])}
                    max={200}
                    min={80}
                    step={5}
                    className="w-full"
                  />
                  <div className="text-xs text-muted-foreground mt-1 text-right">
                    רדיוס: {containerRadius}px
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block text-right">קצב התפשטות</label>
                  <Slider
                    value={[expansion]}
                    onValueChange={(value) => setExpansion(value[0])}
                    max={100}
                    min={10}
                    step={5}
                    className="w-full"
                  />
                  <div className="text-xs text-muted-foreground mt-1 text-right">
                    אנרגיה תרמית: {expansion}
                  </div>
                </div>
              </div>
            </Card>

            {/* Metrics */}
            <Card className="p-6 bg-meter-bg border-card-border" dir="rtl">
              <h3 className="text-lg font-semibold mb-4 text-primary text-right">מדדים פיזיקליים</h3>
              
              <div className="space-y-4">
                <div className="bg-background/20 rounded-lg p-3 border border-border text-right">
                  <div className="text-sm text-muted-foreground">נפח</div>
                  <div className="text-xl font-bold text-gas-medium">{metrics.volume.toLocaleString()}</div>
                  <div className="text-xs text-muted-foreground">פיקסלים²</div>
                </div>

                <div className="bg-background/20 rounded-lg p-3 border border-border text-right">
                  <div className="text-sm text-muted-foreground">צפיפות</div>
                  <div className="text-xl font-bold text-gas-high">{metrics.density}</div>
                  <div className="text-xs text-muted-foreground">גז/יחידת נפח</div>
                </div>

                <div className="bg-background/20 rounded-lg p-3 border border-border text-right">
                  <div className="text-sm text-muted-foreground">לחץ</div>
                  <div className="text-xl font-bold text-gas-low">{metrics.pressure}</div>
                  <div className="text-xs text-muted-foreground">יחידות יחסיות</div>
                </div>

                <div className="bg-background/20 rounded-lg p-3 border border-border text-right">
                  <div className="text-sm text-muted-foreground">מסת החומר</div>
                  <div className="text-xl font-bold text-gas-particle">{GAS_MASS}</div>
                  <div className="text-xs text-muted-foreground">גרם (קבוע)</div>
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* Simple Explanation */}
        <Card className="mt-6 p-6 bg-card border-card-border" dir="rtl">
          <h3 className="text-lg font-semibold mb-4 text-primary text-right">איך זה עובד? הסבר פשוט</h3>
          <div className="grid md:grid-cols-2 gap-6 text-base text-white leading-relaxed text-right">
            <div>
              <h4 className="font-medium text-white mb-2">🎈 מה זה גז?</h4>
              <p>גז הוא חומר שמורכב מחלקיקים קטנים מאוד שזורמים חופשי.</p>
              <p>החלקיקים האלו תמיד נעים ומתנגשים אחד בשני ובדפנות הכלי.</p>
            </div>
            <div>
              <h4 className="font-medium text-white mb-2">📏 כשהכלי גדל</h4>
              <p>כשהכלי נהיה גדול יותר, לחלקיקי הגז יש יותר מקום להסתובב.</p>
              <p>זה אומר שהם פחות "צפופים" - יש פחות חלקיקים בכל מקום.</p>
            </div>
            <div>
              <h4 className="font-medium text-white mb-2">💨 למה הלחץ יורד?</h4>
              <p>לחץ = כמה חזק החלקיקים דוחפים את דפנות הכלי.</p>
              <p>כשיש יותר מקום, פחות חלקיקים נוגעים בדפנות = פחות לחץ.</p>
            </div>
            <div>
              <h4 className="font-medium text-white mb-2">⚖️ המסה לא משתנה</h4>
              <p>כמות החלקיקים נשארת אותו דבר - רק יש להם יותר מקום.</p>
              <p>זה כמו שתפזרו את אותם הכדורים בקופסה גדולה יותר.</p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};
